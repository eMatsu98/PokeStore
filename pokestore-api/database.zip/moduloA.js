
const common= require('./common')
const dato=common();

module.exports=function(){
    console.log('el mensaje guardado es :', dato);
}