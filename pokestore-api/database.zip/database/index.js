const connect= require('./connect');
const db= require('./database');
module.exports={
    connect,
    db
}